OPTIMIZE demo.retail.customers ZORDER BY (customer_id);
