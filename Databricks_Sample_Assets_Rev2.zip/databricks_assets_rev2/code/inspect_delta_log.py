# See PPT for examples. Use DeltaTable.history and spark.read.json on _delta_log
